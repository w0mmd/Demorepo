﻿using DVLD.Applications;
using DVLD.Global_Classes;
using DVLD.Licenses.Local_Licenses;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Licenses.Detained_Licenses
{
    public partial class frmDetainLicenseApplication : Form
    {
        int _LicenseID = -1;
        clsLicense _License;
        public frmDetainLicenseApplication()
        {
            InitializeComponent();
        }

        private void frmDetainLicenseApplication_Load(object sender, EventArgs e)
        {
            llblShowLicenseInfo.Enabled = false;
            llblShowLicenseHistory.Enabled = false;
        }

        private void ctrlDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            _LicenseID = obj;


            if(clsDetainedLicense.IsLicenseDetained(_LicenseID))
            {
                MessageBox.Show("License is already detained!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                llblShowLicenseInfo.Enabled = false;
                llblShowLicenseHistory.Enabled = false;
                btnDetain.Enabled = false;
                return;
            }
            _License = clsLicense.Find(_LicenseID);

            lblLicenseID.Text = _LicenseID.ToString();
            lblCreatedBy.Text = clsGlobal.CurrentUser.UserName.ToString();
            lblDetainDate.Text = DateTime.Now.ToShortDateString();
            btnDetain.Enabled = true;


        }

        private void txtFineFees_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(txtFineFees.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtFineFees, "This field must be filled!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtFineFees, "");
            }
        }

        private void btnDetain_Click(object sender, EventArgs e)
        {
            float FineFees = Convert.ToSingle(txtFineFees.Text.Trim());

            int DetainID = _License.Detain(FineFees, clsGlobal.CurrentUser.UserID);
            lblDetainID.Text = DetainID.ToString();

            if(DetainID == -1)
            {
                MessageBox.Show("Process failed!", "Not saved",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Detained License is saved successfully!", "Saved",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            ctrlDriverLicenseInfoWithFilter1.FilterEnabled = false;
            btnDetain.Enabled = false;
            txtFineFees.Enabled = false;
            llblShowLicenseInfo.Enabled = true;
            llblShowLicenseHistory.Enabled = true;

        }

        private void ctrlDriverLicenseInfoWithFilter1_Load(object sender, EventArgs e)
        {

        }

        private void llblShowLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form frm = new frmShowLicenseInfo(_LicenseID);
            frm.ShowDialog();
        }

        private void llblShowLicenseHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int PersonID = _License.DriverInfo.PersonInfo.PersonID;
            Form frm = new frmShowPersonLicenseHistory(PersonID);
            frm.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
