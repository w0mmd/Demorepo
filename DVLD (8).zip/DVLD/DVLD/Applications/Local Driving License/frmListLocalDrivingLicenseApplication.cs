﻿using DVLD.Licenses;
using DVLD.Licenses.Local_Licenses;
using DVLD.Tests;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Applications.Local_Driving_License
{
    public partial class frmListLocalDrivingLicenseApplication : Form
    {
        private static DataTable _dtAllApplications = clsLocalDrivingLicenseApplication.GetAllLocalDrivingLicenseApplications();
        private DataTable _dtApplications = _dtAllApplications.DefaultView.ToTable(false, "LocalDrivingLicenseApplicationID", "ClassName",
            "NationalNo", "FullName", "ApplicationDate", "PassedTestCount", "Status");


        public frmListLocalDrivingLicenseApplication()
        {
            InitializeComponent();
        }

        private void frmListLocalDrivingLicenseApplication_Load(object sender, EventArgs e)
        {
            dgvAllApplications.DataSource = _dtApplications;
            lblRecords.Text = dgvAllApplications.Rows.Count.ToString();
            cbFilterApplications.SelectedIndex = 0;

            if(dgvAllApplications.Rows.Count > 0 )
            {
                dgvAllApplications.Columns[0].HeaderText = "L.D.L.AppID";
                dgvAllApplications.Columns[0].Width = 90;

                dgvAllApplications.Columns[1].HeaderText = "Driving Class";
                dgvAllApplications.Columns[1].Width = 200;

                dgvAllApplications.Columns[2].HeaderText = "National No";
                dgvAllApplications.Columns[2].Width = 90;

                dgvAllApplications.Columns[3].HeaderText = "Full Name";
                dgvAllApplications.Columns[3].Width = 200;

                dgvAllApplications.Columns[4].HeaderText = "Application Date";
                dgvAllApplications.Columns[4].Width = 150;

                dgvAllApplications.Columns[5].HeaderText = "Passed Tests";
                dgvAllApplications.Columns[5].Width = 90;

                dgvAllApplications.Columns[6].HeaderText = "Status";
                dgvAllApplications.Columns[6].Width = 80;

            }


        }

        private void _Refresh()
        {
            _dtAllApplications = clsLocalDrivingLicenseApplication.GetAllLocalDrivingLicenseApplications();
            _dtApplications = _dtAllApplications.DefaultView.ToTable(false, "LocalDrivingLicenseApplicationID", "ClassName",
            "NationalNo", "FullName", "ApplicationDate", "PassedTestCount", "Status");

            dgvAllApplications.DataSource = _dtApplications;
            lblRecords.Text = dgvAllApplications.Rows.Count.ToString();
        }

        private void cbFilterApplications_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbFilterApplications.SelectedIndex == 0)
                txtFilter.Visible = false;
            else
                txtFilter.Visible = true;
        }

        private void txtFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(cbFilterApplications.SelectedIndex == 3)
            {
                if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
                 {
                    e.Handled = true;
                 }
            }
            else
            {
                e.Handled= false;
            }
        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";

            if (string.IsNullOrEmpty(txtFilter.Text))
                return;

            switch(cbFilterApplications.Text)
            {
                case "L.D.L.AppID":
                    FilterColumn = "LocalDrivingLicenseApplicationID";
                    break;
                case "National No":
                    FilterColumn = "NationalNo";
                    break;
                case "Full Name":
                    FilterColumn = "FullName";
                    break;
                case "Status":
                    FilterColumn = "Status";
                    break;
                default:
                    FilterColumn = "None";
                    break;
            }


            if(txtFilter.Text.Trim() == "" || FilterColumn == "None")
            {
                _dtApplications.DefaultView.RowFilter = "";
                lblRecords.Text = dgvAllApplications.Rows.Count.ToString();
            }
            else if(FilterColumn == "LocalDrivingLicenseApplicationID")
            {
                _dtApplications.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, txtFilter.Text.Trim());
            }
            else
            {
                _dtApplications.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, txtFilter.Text.Trim());
                lblRecords.Text = dgvAllApplications.Rows.Count.ToString();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form frmUpdateAddApplication = new frmAddUpdateLocalDrivingLicenseApplication();
            frmUpdateAddApplication.ShowDialog();
            _Refresh();
        }

        private void editApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmUpdateAddApplication = new frmAddUpdateLocalDrivingLicenseApplication((int)dgvAllApplications.CurrentRow.Cells[0].Value);
            frmUpdateAddApplication.ShowDialog();
            _Refresh();
        }

        private void cancelApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int ApplicationID = (int)dgvAllApplications.CurrentRow.Cells[0].Value;

            clsLocalDrivingLicenseApplication LoaclDrivingLicenseApplication =
                clsLocalDrivingLicenseApplication.FindByLocalDrivingAppLicenseID(ApplicationID);

            if(LoaclDrivingLicenseApplication == null)
            {
                MessageBox.Show("Application is not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if(MessageBox.Show("Are you sure you want to cancel application [" + ApplicationID + "]?", "Confirm to cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }

            if(LoaclDrivingLicenseApplication.Cancel())
            {
                
                MessageBox.Show("Application is cancelled successfully!", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _Refresh();
            }
            else
            {
                MessageBox.Show("Application is not cancelled!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void deleteApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LDLApplicationID = (int)dgvAllApplications.CurrentRow.Cells[0].Value;

            clsLocalDrivingLicenseApplication LocalDrivingLicenseApplication =
                clsLocalDrivingLicenseApplication.FindByLocalDrivingAppLicenseID(LDLApplicationID);

            if(LocalDrivingLicenseApplication == null)
            {
                MessageBox.Show("Application is not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if(LocalDrivingLicenseApplication.ApplicationStatus == clsApplication.enApplicationStatus.Completed)
            {
                MessageBox.Show("Completed applications cannot be deleted.",
            "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(LocalDrivingLicenseApplication.ApplicationStatus == clsApplication.enApplicationStatus.Cancelled)
            {
                MessageBox.Show("Cancelled applications cannot be deleted.",
            "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this application?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
            {
                if(LocalDrivingLicenseApplication.Delete())
                {
                    MessageBox.Show("Application is deleted successfully!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    _Refresh();
                }
                else
                {
                    MessageBox.Show("deletion failed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
        }

        private void showApplicationDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmShowApplicationInfo = new frmLocalDrivingLicenseApplicationInfo((int)dgvAllApplications.CurrentRow.Cells[0].Value);
            frmShowApplicationInfo.ShowDialog();
        }

        private void scheduleVisionTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
           Form frm = new frmListTestAppointments((int)dgvAllApplications.CurrentRow.Cells[0].Value, clsTestType.enTestType.VisionTest);
            frm.ShowDialog();
        }

        private void scheduleWrittenTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new frmListTestAppointments((int)dgvAllApplications.CurrentRow.Cells[0].Value, clsTestType.enTestType.WrittenTest);
            frm.ShowDialog();
        }

        private void scheduleStreetTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new frmListTestAppointments((int)dgvAllApplications.CurrentRow.Cells[0].Value, clsTestType.enTestType.StreetTest);
            frm.ShowDialog();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void issueDrivingLicenseFirstTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new frmIssueDriverLicenseFirstTime((int)dgvAllApplications.CurrentRow.Cells[0].Value);
            frm.ShowDialog();
        }

        private void showLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LocalDrivingLicenseApplicationID = (int)dgvAllApplications.CurrentRow.Cells[0].Value;
            int LicenseID =
                clsLocalDrivingLicenseApplication.FindByLocalDrivingAppLicenseID(LocalDrivingLicenseApplicationID).GetActiveLicenseID();

            if (LicenseID != -1)
            {
                Form frm = new frmShowLicenseInfo(LicenseID);
                frm.ShowDialog();
            }
            else
            {
                MessageBox.Show("No License Found!", "No License", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LocalDrivingLicenseApplicationID = (int)dgvAllApplications.CurrentRow.Cells[0].Value;
            int PersonID =
                clsLocalDrivingLicenseApplication.FindByLocalDrivingAppLicenseID(LocalDrivingLicenseApplicationID).ApplicantPersonID;

            Form frm = new frmShowPersonLicenseHistory(PersonID);
            frm.ShowDialog();
        }
    }
}
