﻿using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.People.Controls
{
    public partial class ctrlPersonCardWithFilter : UserControl
    {
        public event Action<int> OnPersonSelected;

        protected virtual void PersonSelected(int PersonID)
        {
            Action<int> handler = OnPersonSelected;
            if(handler != null)
            {
                handler(PersonID);
            }
        }

        private bool _ShowAddPerson = true;

        public bool ShowAddPerson
        {
            get {  return _ShowAddPerson; }
            set 
            {
                _ShowAddPerson = value;
                btnAdd.Visible = _ShowAddPerson;
            }
        }

        private bool _FilterEnabled = true;

        public bool FilterEnabled
        {
            get { return _FilterEnabled; }
            set
            {
                _FilterEnabled = value;
                groupBox1.Enabled = _FilterEnabled;
            }
        }

        private int _PersonID;

        public int PersonID
        {
            get { return ctrlPersonCard1.PersonID; }
        }

        public  clsPerson SelectedPersonInfo
        {
            get { return ctrlPersonCard1.SelectedPersonInfo;}
        }


        public ctrlPersonCardWithFilter()
        {
            InitializeComponent();
        }

        private void ctrlPersonCardWithFilter_Load(object sender, EventArgs e)
        {

        }

        public void LoadPersonInfo(int PersonID)
        {
            cbFilterPeople.SelectedIndex = 0;
            txtFilter.Text = PersonID.ToString();
            FindNow();
        }

        public void ResetValuesToDefault()
        {
            cbFilterPeople.SelectedIndex = 0;
            txtFilter.Text = "";
            ctrlPersonCard1.ResetValuesToDefault();
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmAddUpdatePerson frm = new frmAddUpdatePerson();

            frm.DataBack += LoadData_DataBack;

            frm.ShowDialog();
        }

        private void LoadData_DataBack(object sender, int PersonID)
        {
            cbFilterPeople.SelectedIndex = 1;
            txtFilter.Text = PersonID.ToString();
            ctrlPersonCard1.LoadData(PersonID);
        }

        private void FindNow()
        {
            switch(cbFilterPeople.Text)
            {
                case "Person ID":
                    ctrlPersonCard1.LoadData(int.Parse(txtFilter.Text));
                    break;
                case "National No":
                    ctrlPersonCard1.LoadData(txtFilter.Text.Trim());
                    break;
                default:
                    break;
            }
            if (OnPersonSelected != null && FilterEnabled)
            {
                OnPersonSelected(ctrlPersonCard1.PersonID);
            }
        }

        private void cbFilterPeople_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFilter.Text = "";
            txtFilter.Focus();
            txtFilter.Visible = true;

        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some fileds are not valid!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            FindNow();
        }

        private void txtFilter_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(txtFilter.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtFilter, "Text box must be filled!");
            }
            else
            {
                e.Cancel= false;
                errorProvider1.SetError(txtFilter, null);
            }
        }

        private void txtFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnFind.PerformClick();
            }

            if (cbFilterPeople.Text == "Person ID")
                e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);


        }
    }
}
