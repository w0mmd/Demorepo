﻿using DVLD_Business;
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DVLD.Properties;
using DVLD.Global_Classes;
using System.Net.Http.Headers;

namespace DVLD.People
{
    public partial class frmAddUpdatePerson : Form
    {
        public delegate void DataBackEventHandler(object sender, int PersonID);
        public event DataBackEventHandler DataBack;

        public enum enMode {AddNew = 0, Update = 1};
        public enum enGender {Male = 0, Female = 1};


        private enMode Mode;
        int _PersonID = -1;
        clsPerson _person;

        public frmAddUpdatePerson(int PersonID)
        {
            InitializeComponent();
            _PersonID = PersonID;
            Mode = enMode.Update;
        }
        public frmAddUpdatePerson()
        {
            InitializeComponent();
            Mode = enMode.AddNew;
        }

        private void frmAddUpdatePerson_Load(object sender, EventArgs e)
        {
            _ResetDefaultValues();

            if(Mode == enMode.Update)
            _LoadData();
        }

        private void _FillCountriesInComboBox()
        {
            DataTable dt = new DataTable();
            dt = clsCountry.GetAllCountries();

            foreach(DataRow row in dt.Rows)
            {
                cbCountry.Items.Add(row["CountryName"]);
            }

        }

        private void _ResetDefaultValues()
        {
            _FillCountriesInComboBox();

            if (Mode == enMode.AddNew)
            {
                lblModeName.Text = "Add New Person";
                _person = new clsPerson();
           
            }
            else
            {
                lblModeName.Text = "Update Person";
            }

            if (rbMale.Checked)
                pictureBox4.Image = Resources.boy;
            else
                pictureBox4.Image = Resources.girl;

            llblRemove.Visible = (pictureBox4.ImageLocation != null);

            dateTimePicker1.MaxDate = DateTime.Now.AddYears(-18);
            dateTimePicker1.Value = dateTimePicker1.MaxDate;

            dateTimePicker1.MinDate = DateTime.Now.AddYears(-100);

            cbCountry.SelectedIndex = cbCountry.FindString("Jordan");

            txtFirstName.Text = "";
            txtSecondName.Text = "";
            txtThirdName.Text = "";
            txtLastName.Text = "";
            txtNationalNo.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtEmail.Text = "";
            rbMale.Checked = true;

        }

        private bool _HandleImagePerson()
        {
            if(_person.ImagePath != pictureBox4.ImageLocation)
            {
                if (_person.ImagePath != "")
                {
                    try
                    {
                        File.Delete(_person.ImagePath);
                    }
                    catch (IOException)
                    {
                        ///LOG IT LATER;
                    }
                }
            }

            if(pictureBox4.ImageLocation != null)
            {
                string sourceImage = pictureBox4.ImageLocation.ToString();
                if(util.CopyImageToProjectImagesFolder(ref sourceImage))
                {
                    pictureBox4.ImageLocation = sourceImage;
                    return true;
                }
                else
                {
                    MessageBox.Show("Error compying image file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;

                }
            }

            return true;
        }

        private void _LoadData()
        {
            _person = clsPerson.Find(_PersonID);

            if(_person == null)
            {
                MessageBox.Show("No person with ID [" + _PersonID + "] is found!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            lblPersonID.Text = _PersonID.ToString();
            txtFirstName.Text = _person.FirstName;
            txtSecondName.Text = _person.SecondName;
            txtThirdName.Text = _person.ThirdName;
            txtLastName.Text = _person.LastName;
            txtNationalNo.Text = _person.NationalNo;
            txtEmail.Text = _person.Email;  
            txtAddress.Text = _person.Address;
            txtPhone.Text = _person.Phone;
            dateTimePicker1.Value = _person.DateOfBirth;
            cbCountry.SelectedIndex = cbCountry.FindString(clsCountry.Find(_person.CountryID).CountryName);
            if (_person.Gender == 0)
                rbMale.Checked = true;
            else
                rbFemale.Checked = true;

            if (!string.IsNullOrEmpty(_person.ImagePath))
            {
                pictureBox4.ImageLocation = _person.ImagePath;
                //pictureBox4.Image = new Bitmap(_person.ImagePath);

            }
           

            llblRemove.Visible = (_person.ImagePath != "");

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(!this.ValidateChildren())
            {
                MessageBox.Show("Some fields are not valid!, click on the red icon to know the reason", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!_HandleImagePerson())
                return;

           int CountryID =  clsCountry.Find(cbCountry.Text).CountryID;

            _person.FirstName = txtFirstName.Text.Trim();
            _person.SecondName = txtSecondName.Text.Trim();
            _person.ThirdName = txtThirdName.Text.Trim();
            _person.LastName = txtLastName.Text.Trim();
            _person.CountryID = CountryID;
            _person.Address = txtAddress.Text.Trim();
            dateTimePicker1.MaxDate = DateTime.Now.AddYears(-18);
            _person.DateOfBirth = dateTimePicker1.Value.Date;
            _person.NationalNo = txtNationalNo.Text.Trim();
            _person.Email = txtEmail.Text.Trim();
            _person.Phone = txtPhone.Text.Trim();

            if (rbMale.Checked)
                _person.Gender = (sbyte)enGender.Male;
            else
                _person.Gender = (sbyte)enGender.Female;

            if (pictureBox4.ImageLocation != null)
                _person.ImagePath = pictureBox4.ImageLocation.ToString();
            else
                _person.ImagePath = "";

            if (_person.Save())
            {
                MessageBox.Show("Saved successfully...", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Mode = enMode.Update;
                lblModeName.Text = "Update Person";
                lblPersonID.Text = _person.PersonID.ToString();

                DataBack?.Invoke(this, _person.PersonID);
            }
            else
            {
                MessageBox.Show("Could not be saved!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }

        private void txtNationalNo_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(txtNationalNo.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtNationalNo, "Textbox should be filled!");
                return;
            }
            else if(txtNationalNo.Text.Trim() != _person.NationalNo && clsPerson.IsPersonExist(txtNationalNo.Text.Trim()))
            {
                e.Cancel = true;
                txtNationalNo.Focus();
                errorProvider1.SetError(txtNationalNo, "National number is already used!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtNationalNo, null);
            }
        }
        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {

            if (txtEmail.Text.Trim() == "")
                return;

            if (!clsValidation.ValidateEmail(txtEmail.Text))
            {
                e.Cancel = true;
                txtEmail.Focus();
                errorProvider1.SetError(txtEmail, "Correct email is required!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtEmail, null);
            }
        }

        private void txtValidating(object sender, CancelEventArgs e)
        {
            TextBox textBox = ((TextBox)sender);

            if (string.IsNullOrEmpty(textBox.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox, "Textbox should be filled!");
                return;
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(textBox, null);
            }
        }

        private void rbFemale_Click(object sender, EventArgs e)
        {
            if (pictureBox4.ImageLocation == null)
            {
                pictureBox4.Image = Resources.girl;
            }
        }
        private void rbMale_Click(object sender, EventArgs e)
        {
            if (pictureBox4.ImageLocation == null)
            {
                pictureBox4.Image = Resources.boy;
            }
        }

        private void llblSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Title = "Save";
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.Filter = @"Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 0;

            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string SelectFilePath = openFileDialog1.FileName;
                pictureBox4.Load(SelectFilePath);
                llblRemove.Visible = true;
            }

        }

        private void llblRemove_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pictureBox4.ImageLocation = null;

            if (rbMale.Checked)
                pictureBox4.Image = Resources.boy;
            else
                pictureBox4.Image = Resources.girl;

            llblRemove.Visible = false;
        }
    }
}
