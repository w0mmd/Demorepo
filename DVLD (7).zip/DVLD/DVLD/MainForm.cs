﻿using DVLD.Global_Classes;
using DVLD.People;
using DVLD.Users;
using DVLD.Login;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DVLD.Applications.ApplicationTypes;
using DVLD.Tests.Test_Types;
using DVLD.Applications.Local_Driving_License;
using DVLD.Applications.Renew_Local_License;
using DVLD.Applications.ReplaceLostOrDamagedLicense;
using DVLD.Drivers;

namespace DVLD
{
    public partial class MainForm : Form
    {
        frmLogin _frmLogin;
        public MainForm(frmLogin frm)
        {
            InitializeComponent();
            _frmLogin = frm;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            //this.WindowState = FormWindowState.Normal;
          //  this.WindowState = FormWindowState.Minimized;
        }

        private void tsb_People_Click(object sender, EventArgs e)
        {
            Form frmListPeople = new frmListPeople();
            frmListPeople.ShowDialog();
        }

        private void tsb_Users_Click(object sender, EventArgs e)
        {
            Form frmListUsers = new frmListUsers();
            frmListUsers.ShowDialog();
        }

        private void currentUserInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmUserInfo = new frmUserInfo(clsGlobal.CurrentUser.UserID);
            frmUserInfo.ShowDialog();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmChangePassword = new frmChangePassword(clsGlobal.CurrentUser.UserID);
            frmChangePassword.ShowDialog();
        }

        private void toolStripSignOut_Click(object sender, EventArgs e)
        {
            clsGlobal.CurrentUser = null;
            _frmLogin.Show(); 
            this.Close();
        }

        private void toolStripApplicationTypes_Click(object sender, EventArgs e)
        {
            Form frmApplicationTypes = new frmListApplicationTypes(); 
            frmApplicationTypes.ShowDialog();
        }

        private void toolStripTestTypes_Click(object sender, EventArgs e)
        {
            Form frmTestTypes = new frmListTestTypes();
            frmTestTypes.ShowDialog();
        }

        private void toolStripMenuLocalLicenseApplications_Click(object sender, EventArgs e)
        {
            Form frmLocalLicenseApplications = new frmListLocalDrivingLicenseApplication();
            frmLocalLicenseApplications.ShowDialog();
        }

        private void localLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmUpdateAddApplication = new frmAddUpdateLocalDrivingLicenseApplication();
            frmUpdateAddApplication.ShowDialog();
        }

        private void RenewtoolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Form frm = new frmRenewLocalDrivingLicenseApplication();
            frm.ShowDialog();
        }

        private void ReplaceOrDamagedDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new frmReplaceLostOrDamagedLicenseApplication();
            frm.ShowDialog();
        }

        private void DriverstoolStripButton2_Click(object sender, EventArgs e)
        {
            Form frm = new frmListDrivers();
            frm.ShowDialog();
        }
    }
}
