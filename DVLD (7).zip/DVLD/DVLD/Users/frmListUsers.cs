﻿using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Users
{
    public partial class frmListUsers : Form
    {
        private static DataTable _dtAllUsers = clsUser.GetAllUsers();
        private DataTable _dtUsers = _dtAllUsers.DefaultView.ToTable(false, "UserID",
            "PersonID", "FullName", "UserName", "Password", "IsActive");


        public frmListUsers()
        {
            InitializeComponent();
        }

        private void frmListUsers_Load(object sender, EventArgs e)
        {
            dgvAllUsers.DataSource = _dtUsers;
            cbFilterUsers.SelectedIndex = 0;
            cbIsActive.Visible = false;
            lblRecords.Text = dgvAllUsers.Rows.Count.ToString();

            if (dgvAllUsers.Rows.Count > 0 )
            {
                dgvAllUsers.Columns[0].HeaderText = "User ID";
                dgvAllUsers.Columns[0].Width = 100;

                dgvAllUsers.Columns[1].HeaderText = "Person ID";
                dgvAllUsers.Columns[1].Width = 120;

                dgvAllUsers.Columns[2].HeaderText = "Full Name";
                dgvAllUsers.Columns[2].Width = 300;

                dgvAllUsers.Columns[3].HeaderText = "UserName";
                dgvAllUsers.Columns[3].Width = 120;

                dgvAllUsers.Columns[4].HeaderText = "Password";
                dgvAllUsers.Columns[4].Width = 120;

                dgvAllUsers.Columns[5].HeaderText = "Is Active";
                dgvAllUsers.Columns[5].Width = 100;
            }
        }

        private void _RefreshUsersList()
        {
            _dtAllUsers = clsUser.GetAllUsers();
            _dtUsers = _dtAllUsers.DefaultView.ToTable(false, "UserID", "PersonID",
                "FullName", "UserName", "Password", "IsActive");

            dgvAllUsers.DataSource = _dtUsers;
            lblRecords.Text = dgvAllUsers.Rows.Count.ToString();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void phoneCallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is not implemented yet!", "Note", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is not implemented yet!", "Note", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmUserInfo = new frmUserInfo((int)dgvAllUsers.CurrentRow.Cells[0].Value);
            frmUserInfo.ShowDialog();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form frmAddUpdateUser = new frmAddUpdateUser();
            frmAddUpdateUser.ShowDialog();
            _RefreshUsersList();
        }

        private void addNewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmAddUpdateUser = new frmAddUpdateUser();
            frmAddUpdateUser.ShowDialog();
            _RefreshUsersList();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmAddUpdateUser = new frmAddUpdateUser((int)dgvAllUsers.CurrentRow.Cells[0].Value);
            frmAddUpdateUser.ShowDialog();
            _RefreshUsersList();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
          int UserId = (int)dgvAllUsers.CurrentRow.Cells[0].Value;
            clsUser user = clsUser.Find(UserId);

            if(MessageBox.Show("Are you sure you want to delete user with ID [" + UserId + "]?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                if(user != null)
                {
                   if(clsUser.DeleteUser(UserId))
                    {
                        MessageBox.Show("User deleted successfully!", "Confirmed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        _RefreshUsersList();

                    }
                    else
                    {
                        MessageBox.Show("Deletion failed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
                else
                {
                    MessageBox.Show("User not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmChangePassword = new frmChangePassword((int)dgvAllUsers.CurrentRow.Cells[0].Value);
            frmChangePassword.ShowDialog();
            _RefreshUsersList();
        }

        private void txtFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilterUsers.SelectedIndex == 3 || cbFilterUsers.SelectedIndex == 1)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
            else
            {
                e.Handled = false;
            }
        }

        private void cbFilterUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilterUsers.SelectedIndex == 0)
            {
                txtFilter.Visible = false;
            }
            else if (cbFilterUsers.SelectedIndex == 5)
            {
                txtFilter.Visible = false;
                cbIsActive.Visible = true;
                cbIsActive.SelectedIndex = 0;
            }
            else
            {
                txtFilter.Visible = true;
                cbIsActive.Visible = false;
            }
            

        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";

            if (cbFilterUsers.Text == "Is Active")
                return;

            switch(cbFilterUsers.Text)
            {
                case "User ID":
                    FilterColumn = "UserID";
                    break;
                case "Person ID":
                    FilterColumn = "PersonID";
                    break;
                case "UserName":
                    FilterColumn = "UserName";
                    break;
                case "Password":
                    FilterColumn = "Password";
                    break;
                default:
                    FilterColumn = "None";
                    break;
            }

            if(txtFilter.Text == "" || FilterColumn == "None")
            {
                _dtUsers.DefaultView.RowFilter = "";
                lblRecords.Text = dgvAllUsers.Rows.Count.ToString();
                return;
            }

            if(FilterColumn == "PersonID" || FilterColumn == "UserID")
            {
                _dtUsers.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, txtFilter.Text);
            }
            else
            {
                _dtUsers.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, txtFilter.Text.Trim());
                lblRecords.Text = dgvAllUsers.Rows.Count.ToString();
            }


        }

        private void cbIsActive_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilterUsers.Text != "Is Active")
                return;
    
                if (cbIsActive.Text == "All")
                {
                    _dtUsers.DefaultView.RowFilter = "";
                }
                if (cbIsActive.Text == "Yes")
                {
                    _dtUsers.DefaultView.RowFilter = "[IsActive] = true";
                }
                if (cbIsActive.Text == "No")
                {
                    _dtUsers.DefaultView.RowFilter = "[IsActive] = false";
                }
                lblRecords.Text = dgvAllUsers.Rows.Count.ToString();
            
        }
    }
}
