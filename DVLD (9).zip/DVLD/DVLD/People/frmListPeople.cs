﻿using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.People
{
    public partial class frmListPeople : Form
    {
        private static DataTable _dtAllPeople = clsPerson.GetAllPersons();
        private DataTable _dtPeople = _dtAllPeople.DefaultView.ToTable(false, "PersonID", "NationalNo",
                                                       "FirstName", "SecondName", "ThirdName", "LastName",
                                                       "GendorCaption", "DateOfBirth", "CountryName",
                                                       "Phone", "Email");

        public frmListPeople()
        {
            InitializeComponent();


        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form frmAddUpdatePerson = new frmAddUpdatePerson();
            frmAddUpdatePerson.ShowDialog();
        }

        private void frmListPeople_Load(object sender, EventArgs e)
        {
            dgvAllPersons.DataSource = _dtPeople;
            cbFilterPeople.SelectedIndex = 10;
            lblRecords.Text = dgvAllPersons.Rows.Count.ToString();
            if(dgvAllPersons.Rows.Count > 0 )
            {
                dgvAllPersons.Columns[0].HeaderText = "Person ID";
                dgvAllPersons.Columns[0].Width = 110;

                dgvAllPersons.Columns[1].HeaderText = "National No";
                dgvAllPersons.Columns[1].Width = 120;

                dgvAllPersons.Columns[2].HeaderText = "First Name";
                dgvAllPersons.Columns[2].Width = 120;

                dgvAllPersons.Columns[3].HeaderText = "Second Name";
                dgvAllPersons.Columns[3].Width = 120;

                dgvAllPersons.Columns[4].HeaderText = "Third Name";
                dgvAllPersons.Columns[4].Width = 120;

                dgvAllPersons.Columns[5].HeaderText = "Last Name";
                dgvAllPersons.Columns[5].Width = 120;

                dgvAllPersons.Columns[6].HeaderText = "Gender Caption";
                dgvAllPersons.Columns[6].Width = 120;

                dgvAllPersons.Columns[7].HeaderText = "Date of Birth";
                dgvAllPersons.Columns[7].Width = 140;

                dgvAllPersons.Columns[8].HeaderText = "Country Name";
                dgvAllPersons.Columns[8].Width = 120;

                dgvAllPersons.Columns[9].HeaderText = "Phone";
                dgvAllPersons.Columns[9].Width = 140;

                dgvAllPersons.Columns[10].HeaderText = "Email";
                dgvAllPersons.Columns[10].Width = 150;
            }
        }

        private void _RefreshPersonsList()
        {
          _dtAllPeople = clsPerson.GetAllPersons();
          _dtPeople = _dtAllPeople.DefaultView.ToTable(false, "PersonID", "NationalNo",
                                                       "FirstName", "SecondName", "ThirdName", "LastName",
                                                       "GendorCaption", "DateOfBirth", "CountryName",
                                                       "Phone", "Email");
            dgvAllPersons.DataSource = _dtPeople;
            lblRecords.Text = _dtPeople.Rows.Count.ToString();
            
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PersonID = (int)dgvAllPersons.CurrentRow.Cells[0].Value;
            Form frmShowPersonInfo = new frmShowPersonInfo(PersonID);
            frmShowPersonInfo.ShowDialog();
            _RefreshPersonsList();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmAddUpdatePerson = new frmAddUpdatePerson();
            frmAddUpdatePerson.ShowDialog();
        }

        private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is not implemented yet.", "Send Email", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void phoneCallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is not implemented yet.", "Phone Call", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PersonID = (int)dgvAllPersons.CurrentRow.Cells[0].Value;
            clsPerson person = clsPerson.Find(PersonID);
            if (MessageBox.Show("Are you sure you want to delete person [" + PersonID + "]?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                if(person != null && File.Exists(person.ImagePath))
                {
                        File.Delete(person.ImagePath);                   
                }
                if (clsPerson.DeletePerson(PersonID))
                {
                    MessageBox.Show("Person deleted successfully...", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Person could not be deleted...", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmAddUpdatePerson = new frmAddUpdatePerson((int)dgvAllPersons.CurrentRow.Cells[0].Value);
            frmAddUpdatePerson.ShowDialog();
            _RefreshPersonsList();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbFilterPeople_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilterPeople.SelectedIndex == 10)
                txtFilter.Visible = false;
            else
                txtFilter.Visible = true;
               
        }

        private void txtFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilterPeople.SelectedIndex == 0) 
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
            else
            {
                e.Handled = false;
            }
        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";

            switch(cbFilterPeople.Text)
            {
                case "Person ID":
                    FilterColumn = "PersonID";
                    break;
                case "First Name":
                    FilterColumn = "FirstName";
                    break;
                case "Second Name":
                    FilterColumn = "SecondName";
                    break;
                case "Third Name":
                    FilterColumn = "ThirdName";
                    break;
                case "Last Name":
                    FilterColumn = "LastName";
                    break;
                case "National No":
                    FilterColumn = "NationalNo";
                    break;
                case "Email":
                    FilterColumn = "Email";
                    break;
                case "Phone":
                    FilterColumn = "Phone";
                    break;
                default:
                    FilterColumn = "None";
                    break;

            }

            if(txtFilter.Text == "" || FilterColumn == "None")
            {
                _dtPeople.DefaultView.RowFilter = "";
                lblRecords.Text = dgvAllPersons.Rows.Count.ToString();
                return;
            }

            if (FilterColumn == "PersonID")
                _dtPeople.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, txtFilter.Text);
            else
                _dtPeople.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, txtFilter.Text.Trim());
            lblRecords.Text = dgvAllPersons.Rows.Count.ToString();

        }
    }
}
