﻿using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Applications.ApplicationTypes
{
    public partial class frmEditApplicationType : Form
    {
        int _ApplicationTypeID = -1;
        clsApplicationType ApplicationType;
        public frmEditApplicationType(int ID)
        {
            InitializeComponent();
            this._ApplicationTypeID = ID;
        }

        private void frmEditApplicationType_Load(object sender, EventArgs e)
        {
            _LoadData();
        }

        private void _LoadData()
        {
            ApplicationType = clsApplicationType.GetApplicationTypeByID(this._ApplicationTypeID);

            if(ApplicationType == null)
            {
                MessageBox.Show("No application is found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            lblID.Text = ApplicationType.ApplicationTypeID.ToString();
            txtTitle.Text = ApplicationType.ApplicationTypeTitle.ToString();
            txtFees.Text = ApplicationType.ApplicationTypeFees.ToString();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtFees.Text == "" || txtTitle.Text == "")
            {
                MessageBox.Show("Text box must be filled!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            ApplicationType.ApplicationTypeTitle = txtTitle.Text;
            ApplicationType.ApplicationTypeFees = Convert.ToDecimal(txtFees.Text);

            if(ApplicationType.UpdateApplicationTypes())
            {
                MessageBox.Show("Application type is updated successfully!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Application type is not saved!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void txtFees_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar))
                return;

            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
    }
}
