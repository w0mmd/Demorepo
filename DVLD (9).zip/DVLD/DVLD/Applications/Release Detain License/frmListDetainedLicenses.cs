﻿using DVLD.Licenses;
using DVLD.Licenses.Detained_Licenses;
using DVLD.Licenses.Local_Licenses;
using DVLD.People;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Applications.Release_Detain_License
{
    public partial class frmListDetainedLicenses : Form
    {
        DataTable _dtDetainedLicenses;
        public frmListDetainedLicenses()
        {
            InitializeComponent();
        }

        private void frmListDetainedLicenses_Load(object sender, EventArgs e)
        {
            _dtDetainedLicenses = clsDetainedLicense.GetAllDetainedLicenses(); 
            dgvAllDetainedLicenses.DataSource = _dtDetainedLicenses;
            lblRecords.Text = dgvAllDetainedLicenses.Rows.Count.ToString();
            cbFilterDetainedLicenses.SelectedIndex = 0;
            cbIsReleased.SelectedIndex = 0;
            cbIsReleased.Visible = false;

            if(dgvAllDetainedLicenses.Rows.Count > 0)
            {
                dgvAllDetainedLicenses.Columns[0].HeaderText = "D.ID";
                dgvAllDetainedLicenses.Columns[0].Width = 50;
                
                dgvAllDetainedLicenses.Columns[1].HeaderText = "L.ID";
                dgvAllDetainedLicenses.Columns[1].Width = 50;
                
                dgvAllDetainedLicenses.Columns[2].HeaderText = "D.Date";
                dgvAllDetainedLicenses.Columns[2].Width = 130;
                
                dgvAllDetainedLicenses.Columns[3].HeaderText = "Is Released";
                dgvAllDetainedLicenses.Columns[3].Width = 80;
                
                dgvAllDetainedLicenses.Columns[4].HeaderText = "Fine Fees";
                dgvAllDetainedLicenses.Columns[4].Width = 100;
                
                dgvAllDetainedLicenses.Columns[5].HeaderText = "Released Date";
                dgvAllDetainedLicenses.Columns[5].Width = 150;

                dgvAllDetainedLicenses.Columns[6].HeaderText = "N.No";
                dgvAllDetainedLicenses.Columns[6].Width = 70;

                dgvAllDetainedLicenses.Columns[7].HeaderText = "Full Name";
                dgvAllDetainedLicenses.Columns[7].Width = 200;

                dgvAllDetainedLicenses.Columns[8].HeaderText = "Release App.ID";
                dgvAllDetainedLicenses.Columns[8].Width = 100;
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDetain_Click(object sender, EventArgs e)
        {
            Form frm = new frmDetainLicenseApplication();
            frm.ShowDialog();
        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            Form frm = new frmReleaseDetainedLicenseApplication();
            frm.ShowDialog();
        }

        private void showPersonDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LicenseID = (int)dgvAllDetainedLicenses.CurrentRow.Cells[1].Value;
            clsLicense License = clsLicense.Find(LicenseID);
            Form frm = new frmShowPersonInfo(License.DriverInfo.PersonInfo.PersonID);
            frm.ShowDialog();
        }

        private void showLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LicenseID = (int)dgvAllDetainedLicenses.CurrentRow.Cells[1].Value;
            Form frm = new frmShowLicenseInfo(LicenseID);
            frm.ShowDialog();
        }

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LicenseID = (int)dgvAllDetainedLicenses.CurrentRow.Cells[1].Value;
            clsLicense License = clsLicense.Find(LicenseID);
            Form frm = new frmShowPersonLicenseHistory(License.DriverInfo.PersonInfo.PersonID);
            frm.ShowDialog();
        }

        private void releaseDetainLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LicenseID = (int)dgvAllDetainedLicenses.CurrentRow.Cells[1].Value;
            Form frm = new frmReleaseDetainedLicenseApplication(LicenseID);
            frm.ShowDialog();
        }

        private void cbFilterDetainedLicenses_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilterDetainedLicenses.SelectedIndex == 1)
            {
                cbIsReleased.Visible = true;
                txtFilter.Visible = false;

            }
            else if(cbFilterDetainedLicenses.SelectedIndex == 0)
            {
                cbIsReleased.Visible = false;
                txtFilter.Visible = false; 
            }
            else
            {
                cbIsReleased.Visible = false;
                txtFilter.Visible = true;
            }

        }

        private void cbIsReleased_SelectedIndexChanged(object sender, EventArgs e)
        {
            string FilterColumn = "IsReleased";
            string FilterValue = cbIsReleased.Text;

            switch(FilterValue)
            {
                case "All":
                    break;
                case "Yes":
                    FilterValue = "1";
                    break;
                case "No":
                    FilterValue = "0";
                    break;
            }

            if (FilterValue == "All")
                _dtDetainedLicenses.DefaultView.RowFilter = "";
            else
                _dtDetainedLicenses.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, FilterValue);

            lblRecords.Text = dgvAllDetainedLicenses.Rows.Count.ToString();

        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            if (cbFilterDetainedLicenses.SelectedIndex == 1)
                return;

            string FilterName = "";

            switch(cbFilterDetainedLicenses.Text)
            {
                case "Detain ID":
                    FilterName = "DetainID";
                    break;
                case "Is Released":
                    FilterName = "IsReleased";
                    break;
                case "National No.":
                    FilterName = "NationalNo";
                    break;
                case "Full Name":
                    FilterName = "FullName";
                    break;
                case "Release Application ID":
                    FilterName = "ReleaseApplicationID";
                    break;
                default:
                    FilterName = "None";
                    break;
            }

            if (txtFilter.Text.Trim() == "" || FilterName == "None")
            {
                _dtDetainedLicenses.DefaultView.RowFilter = "";
                lblRecords.Text = dgvAllDetainedLicenses.Rows.Count.ToString();
                return;
            }

            if(FilterName == "DetainID" || FilterName == "ReleaseApplicationID")
            {
                _dtDetainedLicenses.DefaultView.RowFilter = String.Format("[{0}] = {1}", FilterName, txtFilter.Text.Trim());
              
            }
            else
            {
                _dtDetainedLicenses.DefaultView.RowFilter = String.Format("[{0}] LIKE '{1}%'", FilterName, txtFilter.Text.Trim());
            }

            lblRecords.Text = dgvAllDetainedLicenses.Rows.Count.ToString();

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            releaseDetainLicenseToolStripMenuItem.Enabled = !(bool)dgvAllDetainedLicenses.CurrentRow.Cells[3].Value;

        }
    }
}
