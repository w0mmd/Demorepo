﻿using DVLD.Global_Classes;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Tests
{
    public partial class frmTakeTest : Form
    {
        int _TestAppointmentID = -1;
        clsTestAppointment _TestAppointment;
        int _TestID = -1;
        clsTest _Test;
        clsTestType.enTestType _TestType;


        public frmTakeTest(int TestAppointmentID, clsTestType.enTestType TestType)
        {
            InitializeComponent();
            _TestAppointmentID = TestAppointmentID;
            _TestType = TestType;
        }

        private void frmTakeTest_Load(object sender, EventArgs e)
        {
            ctrlScheduledTest1.TestTypeID = _TestType;
            ctrlScheduledTest1.LoadData(_TestAppointmentID);

            if(ctrlScheduledTest1.TestAppointmentID == -1)
                btnSave.Enabled = false;
            else
                btnSave.Enabled = true;

            int _TestID = ctrlScheduledTest1.TestID;
            if(_TestID != -1)
            {
                _Test = clsTest.Find(_TestID);

                if(_Test.TestResult)
                    rbPass.Checked = true;
                else
                    rbFail.Checked = true;

                txtNotes.Text = _Test.Notes;

                lblUserMessage.Visible = true;
                rbFail.Enabled = false;
                rbPass.Enabled = false;
                txtNotes.Enabled = false;
            }
            else
            {
                _Test = new clsTest();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to save results? Once saved, you can not change results.", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                return;
            }
                _Test.TestResult = rbPass.Checked;
                _Test.TestAppointmentID = _TestAppointmentID;
                _Test.Notes = txtNotes.Text.Trim();
                _Test.CreatedByUserID = clsGlobal.CurrentUser.UserID;

                if(_Test.Save())
                {
              
                    MessageBox.Show("Test info saved successfully!", "Saved",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                    return;
                }
                else
                {
                    MessageBox.Show("Error: Saving is failed!", "Error",
                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            
           
        }
    }
}
