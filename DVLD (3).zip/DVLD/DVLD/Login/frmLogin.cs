﻿using DVLD.Global_Classes;
using DVLD_Business;
using System;
using DVLD.Global_Classes;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Login
{
    public partial class frmLogin : Form
    {

        public frmLogin()
        {
            InitializeComponent();

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.BackColor = Color.White;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.White;
        }

        private void pbClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            panel2.BackColor = Color.FromArgb(158, 5, 33);
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            string StoredUsername = "", StoredPassword = "";

            if(clsGlobal.GetStoredCredential(ref StoredUsername, ref StoredPassword))
            {
                txtUsername.Text = StoredUsername;
                txtPassword.Text = StoredPassword;
                cbRememberMe.Checked = true;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            clsUser user = clsUser.FindByUsernameAndPassword(txtUsername.Text.Trim(), txtPassword.Text.Trim());

            if (user != null && user.Password == txtPassword.Text)
            {
              
                    if(cbRememberMe.Checked)
                    {
                        clsGlobal.RememberUsernameAndPassword(txtUsername.Text, txtPassword.Text);
                    }
                    else
                    {
                        clsGlobal.RememberUsernameAndPassword("","");
                    }
                if (user.IsActive)
                {


                    clsGlobal.CurrentUser = user;
                    this.Hide();
                    MainForm frmMain = new MainForm(this);
                    frmMain.ShowDialog();
                }
                else
                {
                    MessageBox.Show("User is not active!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Username/ Password is not found!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

         
    }
}
