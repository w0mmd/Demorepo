﻿using DVLD_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD_Business
{
    public class clsTestType
    {
        public enum enTestType { VisionTest = 1, WrittenTest = 2, StreetTest  = 3 };
        public clsTestType.enTestType TestTypeID { get; set; }
        public string TestTypeTitle { get; set; }
        public string TestTypeDescription { get; set; }
        public float TestTypeFees { get; set; }

        private clsTestType(clsTestType.enTestType TestTypeID, string TestTypeTitle,
            string TestTypeDescription, float TestTypeFees)
        {
            this.TestTypeID = TestTypeID;
            this.TestTypeTitle = TestTypeTitle;
            this.TestTypeDescription = TestTypeDescription;
            this.TestTypeFees = TestTypeFees;
        }

        public static DataTable GetAllTestTypes()
        {
            return clsTestTypeData.GetAllTestTypes();
        }

        public bool UpdateTestTypes()
        {
            return clsTestTypeData.UpdateTestType((int)this.TestTypeID,
                this.TestTypeTitle, this.TestTypeDescription, this.TestTypeFees);
        }

        public static clsTestType GetTestTypeByID(clsTestType.enTestType ID)
        {
            string Title = "", Description = ""; float Fees = -1;

            if (clsTestTypeData.GetTestTypeInfoByID((int)ID, ref Title, ref Description, ref Fees))
            {
                return new clsTestType(ID, Title, Description, Fees);
            }
            else
            {
                return null;
            }
        }

    }
}
